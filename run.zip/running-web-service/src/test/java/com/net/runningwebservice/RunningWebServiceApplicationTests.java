package com.net.runningwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunningWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
