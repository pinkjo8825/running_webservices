package com.net.runningwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunningWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunningWebServiceApplication.class, args);
	}

}
